//
//  NavigationSwiftUIApp.swift
//  NavigationSwiftUI
//
//  Created by 范桶 on 2021/5/5.
//

import SwiftUI

@main
struct NavigationSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
