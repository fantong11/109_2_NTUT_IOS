//
//  SwiftUIComponentApp.swift
//  SwiftUIComponent
//
//  Created by 范桶 on 2021/5/12.
//

import SwiftUI

@main
struct SwiftUIComponentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
