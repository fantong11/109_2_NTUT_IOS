//
//  RockPaperScissor.swift
//  FingerGuessingGame
//
//  Created by 范桶 on 2021/5/19.
//

import Foundation

enum Finger: String, CaseIterable {
    case paper = "paper"
    case rock = "rock"
    case scissor = "scissor"
}

